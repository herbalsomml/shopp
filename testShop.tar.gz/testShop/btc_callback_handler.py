import configparser

from fastapi import FastAPI, HTTPException
from fastapi import status as stst


import tgbot.services.sqlite
from tgbot.services.sqlite import get_btc_paymentx, add_refill, update_user, remove_btc_paymentx
from tgbot.utils.utils_functions import get_date, get_unix, send_admins

from design import refill_success_text

from aiogram import Bot
import asyncio

app = FastAPI()

cfg = configparser.ConfigParser()
cfg.read("settings.ini")
KEY = cfg['settings']['secret_key'].strip().replace(' ', '')
BOT_TOKEN = cfg['settings']['token'].strip().replace(' ', '')


async def send_message_to_user(user_id: int, message_text: str):
    bot = Bot(token=BOT_TOKEN)
    await bot.send_message(chat_id=user_id, text=message_text)


# Example usage:

# h<gA.s9dz%}WEm2p
@app.get("/callback/")
def handle_callback(status: int, addr: str, value: int, txid: str, secret_key: str):
    if secret_key != KEY:
        raise HTTPException(status_code=stst.HTTP_401_UNAUTHORIZED)
    print(f"Transaction from {addr} with {value / 100_000_000}BTC and {txid=}\n secret_key auth success")
    if status == 0:
        r = get_btc_paymentx(addr, value)
        if r:
            asyncio.run(send_message_to_user(r['user_id'],
                                             f"Ваш платёж на адрес {addr} суммой {r['amount_rubs']} найден и ожидает подтверждения"))
    elif status == 1:
        r = get_btc_paymentx(addr, value)
        if r:
            asyncio.run(send_message_to_user(r['user_id'],
                                             f"Ваш платёж на адрес {addr} суммой {r['amount_rubs']} подтвержден на 50%"))
    elif status == 2:
        r = get_btc_paymentx(addr, value)
        if r:

            ##get_user = tgbot.services.sqlite.get_user(user_id=r['user_id'])

            ##add_refill(get_user['user_id'], get_user['user_login'], get_user['user_name'], "btc",
                  ##      r['amount_rubs'], txid, 'btc', get_date(), get_unix())

            ##update_user(
            ##    r['user_id'],
             ##   user_balance=get_user['user_balance'] + r['amount_rubs'],
              ##  user_refill=get_user['user_refill'] + r['amount_rubs'],
            ##)
            ##remove_btc_paymentx(addr, value)
            ##asyncio.run(send_message_to_user(r['user_id'], f"Ваш баланс был пополнен на {r['amount_rubs']}"))
            user = tgbot.services.sqlite.get_user(id=r['user_id'])
            msg = f"💰 Произошло пополнение баланса! \n" \
                  f"👤 Пользователь: <b>@{user['user_name']}</b> | <a href='tg://user?id={user['id']}'>{user['first_name']}</a> | <code>{user['id']}</code>\n" \
                  f"💵 Сумма пополнения: <code>{r['amount_rubs']} RUB</code>\n" \
                  f"🧾 Чек: <code>{id}</code> \n" \
                  f"⚙️ Способ: <code>Bitcoin</code>"
            await send_admins(msg, True)

            id = get_unix() + r['user_id']

            update_user(id=r['user_id'], balance=int(user['balance']) + int(r['amount_rubs']),
                        total_refill=int(user['total_refill']) + int(r['amount_rubs']),
                        count_refills=int(user['count_refills']) + 1)
            add_refill(r['amount_rubs'], 'Bitcoin', r['user_id'], r['user_login'], r['user_name'], comment=id)
            asyncio.run(send_message_to_user(r['user_id'], refill_success_text('Bitcoin', r['amount_rubs'], id)))
    return ""