from decimal import Decimal
import requests as rq

from tgbot.services.sqlite import get_payments
from tgbot.data import config



class BtcApi:
    def __init__(self):
        self.base_url = "https://www.blockonomics.co/api"
        self.token = config.blockonomics_token
        self.headers = {"Authorization": f"Bearer {self.token}"}

    def get_current_price(self):
        return rq.get(f"{self.base_url}/price?currency=RUB").json()['price']

    def convert_rub_to_sat(self, rubs: int):
        price = self.get_current_price()
        BTC = round(Decimal(rubs) / Decimal(price), 10)
        # 1 sat = 0.00000001 BTC
        sat = (BTC // Decimal(0.00000001))
        return sat

    def create_new_address(self):
        result = rq.post(f"{self.base_url}/new_address", headers=self.headers).json()
        if 'error_code' in result:
            if result['error_code'] == 1008:
                print("TOO MANY ADDRESSES")
                result = rq.post(f"{self.base_url}/new_address?reset=1", headers=self.headers).json()
                print(result)
        return result['address']


    def create_order(self, price: int):
        print("Creating order")
        a = self.create_new_address()
        sat = self.convert_rub_to_sat(price)
        return sat, a

# #
# a = BtcApi()
# print(a.create_new_address())
#
